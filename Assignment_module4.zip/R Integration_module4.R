# R Code to Integrate Python Visualization
# install and load required packages ---------------------------------------------------------------------------------------

if (!requireNamespace("pacman")) install.packages("pacman", dependencies = TRUE)

pacman::p_load(
  ggplot2,
  png,
  grid,
  here
)

# Load and Display the Genre Chart
path <- here("most_watched_genres.png")
img <- readPNG(path)
grid::grid.raster(img)

# Similarly, load and display the rating distribution
img2 <- readPNG("rating_distribution.png")
grid::grid.raster(img2)


# The lines of code below create the product class

class Product:
    """Class to manage insurance products."""
    def __init__(self, product_id, name, premium):
        self.product_id = product_id
        self.name = name
        self.premium = premium
        self.status = "Available"  # Available or Suspended

    def update_premium(self, new_premium):
        self.premium = new_premium
        print(f"The premium for product '{self.name}' has been updated to {self.premium}.")

    def suspend(self):
        self.status = "Suspended"
        print(f"The product '{self.name}' has been suspended.")

    def details(self):
        return {
            "Product ID": self.product_id,
            "Name": self.name,
            "Premium": self.premium,
            "Status": self.status,
        }

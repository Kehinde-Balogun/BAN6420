# The lines of code below create the payment class

class Payment:
    """Class to manage payments and penalties."""
    def __init__(self, policyholder, product):
        self.policyholder = policyholder
        self.product = product
        self.status = "Pending"  # Pending, Completed, or Failed

    def process_payment(self):
        if self.policyholder.status == "Active":
            self.status = "Completed"
            print(f"Payment for policyholder {self.policyholder.name} on product {self.product.name} has been completed.")
        else:
            print(f"Payment failed for policyholder {self.policyholder.name} due to suspended status.")

    def payment_reminder(self):
        if self.status == "Pending":
            print(f"Reminder: Payment is pending for policyholder {self.policyholder.name} on product {self.product.name}.")

    def apply_penalty(self):
        print(f"Penalty applied to policyholder {self.policyholder.name} for delayed payment.")

# The lines of code below create the policyholder class

class Policyholder:
    """Class to manage policyholder details and status."""
    def __init__(self, policy_id, name, email):  # contains the policy_id, name, and email of clients
        self.policy_id = policy_id
        self.name = name
        self.email = email
        self.status = "Active"  # Active or Suspended

    def suspend(self):
        self.status = "Suspended"
        print(f"Policyholder {self.name} (ID: {self.policy_id}) has been suspended.")

    def reactivate(self):
        self.status = "Active"
        print(f"Policyholder {self.name} (ID: {self.policy_id}) has been reactivated.")

    def details(self):
        return {
            "Policy ID": self.policy_id,
            "Name": self.name,
            "Email": self.email,
            "Status": self.status,
        }

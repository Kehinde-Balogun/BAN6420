# Load pacman if not already loaded, then load R6 using pacman
if (!requireNamespace("pacman", quietly = TRUE)) install.packages("pacman")
pacman::p_load(R6)

# Define the Worker class
Worker <- R6Class(
  "Worker",
  public = list(
    name = NULL,
    gender = NULL,
    salary = NULL,
    level = NULL,
    
    # Initialize method for Worker
    initialize = function(name, gender, salary) {
      self$name <- name
      self$gender <- gender
      self$salary <- salary
      self$assign_level()
    },
    
    # Method to assign employee level based on salary and gender
    assign_level = function() {
      if (10000 < self$salary && self$salary < 20000) {
        self$level <- "A1"
      } else if (7500 < self$salary && self$salary < 30000 && self$gender == "Female") {
        self$level <- "A5-F"
      } else {
        self$level <- "General"
      }
    },
    
    # Method to generate a payment slip
    generate_payment_slip = function() {
      slip <- paste0(
        "Payment Slip for ", self$name, "\n",
        "Gender: ", self$gender, "\n",
        "Salary: $", format(self$salary, nsmall = 2), "\n",
        "Employee Level: ", self$level, "\n",
        paste(rep("-", 30), collapse = "")
      )
      return(slip)
    }
  )
)

# Function to create random workers
create_workers <- function(num_workers = sample(400:420, 1)) {
  workers <- list()
  
  for (num in 1:num_workers) {
    name <- paste("Worker", num, sep = "_")
    gender <- sample(c("Male", "Female"), 1)
    salary <- runif(1, 5000, 35000)  # Salary between 5000 and 35000
    
    # Create a new Worker object and add it to the list
    worker <- Worker$new(name, gender, salary)
    workers[[num]] <- worker
  }
  
  return(workers)
}

# Main function to process payments
process_payments <- function() {
  workers <- create_workers()
  
  for (worker in workers) {
    cat(worker$generate_payment_slip(), "\n\n")
  }
}

# Run the payment processing function
process_payments()

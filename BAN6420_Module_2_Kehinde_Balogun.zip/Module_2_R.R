# Load pacman and use it to manage packages
if (!require(pacman)) install.packages("pacman")
pacman::p_load(here, readr)  # Load 'here' and 'readr' libraries

# Define ZIP file path using 'here'
zip_file <- here("Employee Profile.zip")

# Unzip the file into a folder named 'Employee Profile'
unzip_dir <- here("Employee Profile")
if (!dir.exists(unzip_dir)) dir.create(unzip_dir)  # Create directory if it doesn't exist

# Try to unzip and handle errors
tryCatch({
  unzip(zip_file, exdir = unzip_dir)
  cat("Unzip successful.\n")
}, error = function(e) {
  cat("Error unzipping file:", e$message, "\n")
})

# Search for CSV files in the unzipped directory
csv_file <- list.files(unzip_dir, pattern = "\\.csv$", full.names = TRUE)

if (length(csv_file) > 0) {
  # Read and display the first CSV file found
  employee_data <- read_csv(csv_file[1])
  print(employee_data)
} else {
  cat("No CSV files found after unzipping.\n")
}
